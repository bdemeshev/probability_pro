# probability_pro

Сборник [листков с задачами](https://github.com/bdemeshev/probability_pro/raw/master/probability_pro.pdf) к семинарам по теории вероятностей.

Дружественный репозиторий с [подборкой контрольных НИУ ВШЭ](https://github.com/bdemeshev/probability_hse_exams/).

Блог [покровка11](https://pokrovka11.wordpress.com).
